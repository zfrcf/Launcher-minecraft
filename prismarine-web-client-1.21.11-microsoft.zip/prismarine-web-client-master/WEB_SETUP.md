# Web client — 1.21.11 / Microsoft / Fabric-server compatibility

## What this fork changes

- Default Minecraft protocol version: **1.21.11**
- Default server: `donutsmp.net:25565`
- Authentication mode: **Microsoft**
- Password field removed from the web UI.
- Azure client ID is read from `config.json`.
- Device-code callback displays the Microsoft sign-in code in the loading screen.
- Existing browser/mobile rendering and touch input are retained.

## Azure

Put the **Application (client) ID** of your Azure app in:

```json
{
  "azureClientId": "YOUR_CLIENT_ID"
}
```

Do **not** put a client secret in this repository or in browser JavaScript.

The Prismarine authentication stack supports Microsoft authentication; custom Azure applications use its MSAL flow. See the Prismarine authentication documentation for the exact Azure setup.

## Fabric

This is the important limitation:

**Prismarine Web Client is not a Fabric client.** It uses Mineflayer/Prismarine protocol code and can connect to compatible Java servers, including servers running Fabric, but it does not load Fabric client mods or a Fabric Loader inside the browser.

Therefore this package is configured for **1.21.11 and Microsoft authentication**, but it does not claim to run Fabric mods client-side.

## Install/build

Node.js 18+ is recommended.

```bash
npm install
npm run build
npm run prod-start
```

For development:

```bash
npm install
npm start
```

## Railway / Render

Use the build command:

```bash
npm install && npm run build
```

and start command:

```bash
npm run prod-start
```

Set the service port using the platform's `PORT` environment variable.

## Security

The browser must never receive an Azure client secret. Only the public client ID belongs in `config.json`.

This project does not include the proprietary Minecraft client or Minecraft assets downloaded from Mojang/Microsoft.
